// console.log("hello");

// setTimeout(()=>{
//     for(let i=1;i<4500;i++){
//         console.log("start printing",i);
//     }
// },100)
// console.log("done printing");


// console.log("hii");

// setTimeout(()=>{
//     for(let i=1;i<10;i++){
//         console.log("arrow function hello",i);
//     }
// },3000)

// function m(){
//     for(let i=1;i<10;i++){
//         console.log("function hello",i);
//     }
// }
// m()
// function fun(){
//     for(let i=1;i<10;i++){
//         console.log("simple function hello",i);
//     }
// }
// fun()

// console.log("execution complete");


