// for(let i=1;i<=10;++i)
// {
//     console.log(`${i} hello world`);
// }

// for(let i=1;i<=10;i=i++)
// {
//     console.log(`${i} hello world`);
// }

// for(let i=1;i<=10;i=++i)
// {
//     console.log(`${i} hello world`);
// }

var i=1;
for(;i<=10;i++)
{
    console.log(`${i} hello world`);
}