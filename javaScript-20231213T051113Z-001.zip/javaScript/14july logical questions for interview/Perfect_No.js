let number=parseInt(prompt("enter your no: "));
let temp=0;

for(let i=1;i<=number/2;i++){
    if(number%i===0){
        temp+=i;
    }
}
if(temp === number && temp!==0){
    document.write("it is a perfect no");
}
else{
    document.write("it is not a perfect no");
}