// var a=20;
// var b=30;
// // var sum=a+b
// document.write(`${a+b}`)

// function fun(){
//     var a=20;
//     var b=30; 
//     var c=40;
//     var d=50;
//     if(a>b){
//         document.write("true")
//     }
//     else if(b>c){
//         document.write("true")
//     }
//     else if(c<d){
//         document.write("true")
//     }
//     else{
//         document.write("false")
//     }
// }
// fun()



// function fun(){
//     var a=20;
//     var b=30;
//     if(a>b){
//         document.write("a is greater")
//     }
//     else{
//         document.write("b is greater than a")
//     }
// }
// fun()


// function fun(){
//     for( i=1;i<=5;i++){
//         for(let j=1;j<=i;j++){
//             document.write("*")
//         }
//         document.writeln("<br>")
//     }
// }
// fun()


// function fun(){
//     var n=5;
//     for( i=1;i<=n;i++){
//         for(let j=1;j<=i;j++){
//             document.write(i)
//         }
//         document.writeln("<br>")
//     }
// }
// fun()


// function fun(){
//     var n=7;
//     for(let i=1;i<=n;i++){
//         for(let j=n;j>=i;j--){
//             document.write("*")
//         }
//         document.write("<br>")
//     }
// }
// fun()


// function fun(){
//     var n=5;
//     for(let i=1;i<=5;i++){
//         for(let j=n-1;j>=i;j--){
//             document.write(" &nbsp ")
//         }
//         for(let k=1;k<=i;k++){
//             document.write("*")
//         }
//         document.write("<br>")
//     }
// }
// fun()


// function fun(){
//     var n=5;
//     for(let i=1;i<=n;i++){
//         for(let j=1;j<i;j++){
//             document.write("  &nbsp  ")
//         }
//         for(let k=n;k>=i;k--){
//             document.write("*")
//         }
//         document.write("<br>")
//     }
// }
// fun()


// function fun(){
//     var n=5;
//     for(let i=1;i<=n;i++){
//         for(let j=n-1;j>=i;j--){
//             document.write(" &nbsp ")
//         }
//         for( let k=1;k<=i;k++){
//             document.write("*")
//         }
//         for( let m=2;m<=i;m++){
//             document.write("*")
//         }
//         document.write("<br>")
//     }
// }
// fun()


// function fun(){
//     var n=5;
//     for( let i=1;i<=n;i++){
//         for( let j=1;j<i;j++){
//             document.write(" &nbsp ")
//         }
//         for( let k=n;k>=i;k--){
//             document.write("*")
//         }
//         for( let m=n;m>i;m--){
//             document.write("*")
//         }
//         document.write("<br>")
//     }
// }
// fun()


 