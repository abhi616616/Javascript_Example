// var n=prompt("user input")

// for(let i=1;i<=n;i++){
//     for(let j=1;j<i;j++){
//         document.write(" &nbsp ")
//     }
//     for(let k=i;k<n;k++){
//         document.write("*")
//     }
//     for(let m=i;m<=n;m++){
//         document.write("*")
//     }
//     document.write("<br>")
// }



//prime number program..
// var n=Number(prompt("enter user no: "))

// var temp=0;

// for(let i=2;i<=n-1;i++){
//     if(n%i==0){
//         temp=temp+1
//     }
// }
// if(temp>=1){
//     document.write("no is not prime")
// }
// else{
//     document.write("prime no")
// }

