// let arr = [1, 2, 3, 4, 5]
// let arr1=[]
// for (let i = arr.length - 1; i >= 0; i--) {
//     arr1.push(arr[i])
// }
// console.log(arr1);


// map function 
// let arr=[1,2,3,4,5]

// let arr1=arr.map((value)=>
//     value*2
// )
// console.log(arr1);


// let str="abhinav";
// let len=str.length;

// let rev="";

// for (let i=len-1;i>=0;i--){
//     rev=rev+str[i]
// }
// console.log(rev);


