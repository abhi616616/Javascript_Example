// function add(hello,hmm){
//     setTimeout(function(){
//         console.log("one",hello);
//         two()
//     },3000)
    
// }
// function two(){
//     console.log("two");
// }
// add("data",two)

let add=function(){
    console.log("add");
}
let two=function(){
    console.log("two");
}
add()
two()