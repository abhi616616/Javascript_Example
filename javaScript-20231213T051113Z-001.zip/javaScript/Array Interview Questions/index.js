// var arr=[1,2,3,4,5,6,7,5,4]  //find a duplicate array.....

// for(let i=0;i<arr.length-1;i++){
//     for(let j=i+1;j<arr.length;j++){
//         if(arr[i]==arr[j]){
//             console.log(arr[i]);
//         }
//     }
// }


// var arr=["c","java","D","python","java"]  //find a duplicate string in array

// for(let i=0;i<arr.length-1;i++){
//     for(let j=i+1;j<arr.length;j++){
//         if(arr[i]==arr[j]){
//             console.log(arr[i]);
//         }
//     }
// }

// let arr=[2,3,1,4,8,9,6,5]  //short an array assending order
// let temp=0
// for(let i=0;i<arr.length;i++){
//     for(let j=i+1;j<arr.length;j++){
//         if(arr[i]>arr[j]){
//             temp=arr[i]
//             arr[i]=arr[j]
//             arr[j]=temp
//         }
//     }
// }
// for(let i=0;i<arr.length;i++){
//     console.log(arr[i]);
// }


// let arr=[1,2,3,4,5,6,7,8,9]  //desending order array....
// let temp=0

// for(let i=0;i<arr.length;i++){
//     for(let j=i+1;j<arr.length;j++){
//         if(arr[i]<arr[j]){
//             temp=arr[i]
//             arr[i]=arr[j]
//             arr[j]=temp
//         }
//     }
// }
// for(let i=0;i<arr.length;i++){
//     console.log(arr[i]);
// }


// let arr=[10,20,5,7,8,4]   //maximum no
// let max=arr[0]

// for(let i=0;i<arr.length;i++){
//     if(arr[i]>max){
//         max=arr[i]
//     }
// }
// console.log(max);


// let arr=[10,20,30,4,3,6]  //minimum no of array
// let min=arr[0]
// for(let i=0;i<arr.length;i++){
//     if(arr[i]<min){
//         min=arr[i]
//     }
// }
// console.log(min);