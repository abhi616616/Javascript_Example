// var a = {name: 'test'};
// var b = {age: 25};
// // output = {name: 'test', age: 25};

// var c=a.concat(b)
// console.log(c);

// var c = [1,2,4,5,6,3,4,5];

// let b=c.sort()
// console.log(b);


