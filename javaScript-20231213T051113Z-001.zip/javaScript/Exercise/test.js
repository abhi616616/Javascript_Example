// var a=20;
// var b=30;

// var sum=a+b;

// console.log(`${a} + ${b} = ${sum} (sum of a & b)`);

////////////////////////

// var a=20;
// var b=30;

// if(a>b){
//     console.log("true");
// }
// else{
//     console.log("false");
// }

///////////////////////////


// var n=5;
// // let n=6;
// for(let i=1;i<=n;i++){
//     console.log(i);
// }

//////////////////////////

