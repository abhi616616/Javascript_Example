// let abhi="abhinav";
// let kum="kumar";

// function fun(){
//     console.log(`${abhi} ${kum}`);
    
// }

// fun();


////////////////////////////

// let n=5;

// function a(){
//     for(var i=1;i<=n;i++)
//     {
//         console.log(`    ${i}`);
//     }
    
// }
// a();

////////////////////////////

// function funName(fname="abhi", lname="kum"){
//     // console.log(`hello ${fname}  ${lname}`);
//     console.log("hello " +  fname  +"    "  +lname);
// }

// // funName("abhinav","kumar");
// funName();

// function sum(a,b){
//     sum=a+b;
//     console.log(`${a}+${b} = ${sum}`);
// }
// sum(20,90);


// let n=3;
// function fun(){
//     for(let i=1;i<=n;i++)
//     {
//         for(let j=1;j<i;j++)
//         {
//             document.write("&nbsp");
//         }
//         for(let k=i;k<n;k++)
//         {
//             document.write("*")
//         }
//         for(let l=i;l<=n;l++)
//         {
//             document.write("*")
//         }
//         document.write("<br>")
//     }
// }
// fun();


// let n=3;
// function fun(){
//     for(let i=1;i<=n;i++)
//     {
//         for(let j=n;j>i;j--)
//         {
//             document.write("&nbsp");
//         }
//         for(let k=1;k<i;k++)
//         {
//             document.write("*");
//         }
//         for(let l=1;l<=i;l++)
//         {
//             document.write("*");
//         }
//         document.write("<br>");
//     }
// }
// fun();


// var emp=[10,20,30,40,50]

// console.log(emp[2]);


//anonymous function
// var sample=function(){
//     document.write("hello");
// }
// sample()


//fat arrow function

// var sample=()=>{
//     document.write("js..")
// }
// sample()

// var sample=()=> document.write("single line")

// sample()


// var arr=[1,2,3,4,5]
// for( var i=0;i<arr.length;i++){
//     console.log(arr[i]);
//     // document.write(arr[i])
// }





