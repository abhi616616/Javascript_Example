// class Abhi{
//     show(){
//         console.log("hello js");
//     }
//     display(){
//         console.log("hello react");
//     }
// }
// var obj=new Abhi
// obj.show()
// obj.display()