// var a=[10,20,30,40,50,[1,2,3,4,5],"abhinav","kumar"]
// console.log(a);
// // document.write(a);

//empty array

// var a=[]
// a.push(10)
// a.push(5)
// a.push(20)
// a.push(30)
// a.push(40)
// a.push(50)
// a.push(60)
// console.log(a);

//array constructor

// var a=Array(10,20,30,40,50,60,70)
// console.log(a);

// var a=Array()
// a.push(1)
// a.push(2)
// a.push(3)
// a.push(4)
// a.push(5)
// console.log(a);

