// object literal
// var a={
//     b: 10,
//     c: 20,
//     d: 30,
//     e: 40 
// }
// console.log(a);

//empty object liteeral

// var a={}
//     a.abhi= 10,
//     a.kumar=20,
//     a.sharma="abhinav",
//     a.singh="kumar",
//     a['salary']="35000"
//     a['age']=25
//     console.log(a);


// //new Object
// var a=new Object()
// a.salary="35000",
// a["age"]=25,
// a.name="abhinav",
// a.age=30

// console.log(a);


