// function fun(){
//     let a=20;
//     let b=30;
//     return a+b;
// }
// var a=fun()
// console.log(`sum of a+b = ${a}`);



// another example 
// function fun(a,b){
//     return a+b
// }
// var a=fun(10,20)
// console.log(a);


// function fun(a,b){
//     return a+b
// }
// console.log(fun(10,20));
// console.log(fun(20,30));
// console.log(fun(30,40));