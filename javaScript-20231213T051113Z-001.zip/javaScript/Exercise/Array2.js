// const a = (() => {
//     var array = [10, 20, 30, 40, 50]
//     for (var i = 0; i < array.length; i++) {
//         document.write(array[i] + ","+"<br>");
//     }
// })
// a()

// const add=function(){
//     var array=[1,2,3,4,5,6,"abhinav","kumar","sharma"]
//     for(var i=0;i<array.length;i++){
//         document.write(array[i]+","+"<br>")
//     }
// }
// add()

// function add(){
//     document.write("hello"+"<br>")
//     var array=[1,2,3,4,5,6,"abhinav","kumar","sharma",[10,20,30,40]]
//     for(var i=0;i<array.length;i++){
//         document.write(array[i]+","+"<br>")
//     }
// }
// add()


// function add(a,b){
//     document.write(a+b+"<br>")
//     document.write(a-b+"<br>")
//     document.write(a/b+"<br>")
//     document.write(a*b+"<br>")
// }
// add(2,5)


// const add=()=>{ document.write("hello")}
// add()
