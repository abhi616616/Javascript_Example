class Ex{
    constructor(){
        console.log("hello js");
    }
}
var obj=new Ex()