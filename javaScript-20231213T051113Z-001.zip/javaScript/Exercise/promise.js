//Asynchronous function

console.log("start");
// setTimeout(()=>{
//     console.log("hello promise");
// },2000)
setTimeout(function show(){
    console.log("hello");
},2000)

console.log("End");


