// let arr=[10,20,30,4,50,60,5]  //maximum no find out
// let max=arr[0]

// for(let i=0;i<arr.length;i++){
//     if(arr[i]>max){
//         max=arr[i]
//     }
// }
// console.log(max);

// let n=11      //given no is prime or not..
// let temp=0
// for(let i=2;i<=n-1;i++){
//     if(n%2==0){
//         temp=temp+1
//     }
// }
//     if(temp>0){
//         console.log("not prime");
//     }
//     else{
//         console.log("prime");
//     }



// let temp=0
// for(let i=1;i<=100;i++){
//     for(let j=2;j<=i-1;j++){
//         if(i%j==0){
//             temp=temp+1
//         }
//     }
//     if(temp==0){
//         console.log(i);
//     }
//     else{
//         temp=0
//     }
// }


// let arr=[10,20,40,3,60,2,1,30]
// let max=arr[0]
// for(let i=0;i<=arr.length;i++){
//     if(arr[i]>max){
//         max=arr[i]
//     }
// }
// console.log(max);