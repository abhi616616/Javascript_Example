// const a=20;
// function fun(){
//     const b=30
//     console.log(a);
// }
// fun()
// console.log(b);





