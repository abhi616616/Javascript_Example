let arr=[5,2,3,4,6]

function fun(x){
    return x%2===0
}

let data=arr.filter(fun)
console.log(data);