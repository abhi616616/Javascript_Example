let arr=[5,2,3,4,6]

function double(x){
    return x*2
}

let data=arr.map(double)
console.log(data);