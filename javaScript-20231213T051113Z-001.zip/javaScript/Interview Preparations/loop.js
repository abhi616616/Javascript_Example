let arr=[1,2,3,4,5]
for(let i=0;i<arr.length;i++)
{
    // console.log(`${arr[i]} ,${[i]}`);
    // console.log(arr[i],[i]);
    console.log(`Array ${i} is ${arr[i]}`)
}