// function Demo(){
//     const array1=[1,2,3,4,5]
//     const arr=array1.map((item)=>item*2+ '')
//     console.log(arr);
// }
// Demo()

// let a=3;
// a=2
// console.log(a);
// var a=3;
// fun()
// function fun(){
//     var a=2;
//     console.log(a);
// }
// fun()
//  var a=3;
// console.log(a);


// Hoisting

// function fun() {
//     console.log("fun");
// }
// function fun1() {
//     console.log("fun1");
// }
// function fun2() {
//     console.log("fun2");
// }
// fun()
// fun1()
// fun2()

// a=5;
// console.log(a);
// let a;
// console.log(a);


// var a = 4;

// function greet() {
//     b = 'hello';
//     console.log(b); // hello
//     var b;
// }

// greet(); // hello
// // console.log(b);


// const arr = [1,2,3,3,4];
// // const ans = [...new Set(arr)]
 
// // console.log(ans)
// console.log([...new Set(arr)])



