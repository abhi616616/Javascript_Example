async function fun(){
    return "abhinav"
}
var a=fun()
console.log(a);